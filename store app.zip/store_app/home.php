<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home </title>
    <link href="static/css/bootstrap.min.css" type="text/css" rel="stylesheet"> 
    <link href="static/css/custom.css" type="text/css" rel="stylesheet">  
    <link href="static/css/custom.css" type="text/css" rel="stylesheet">   
    <script src="static/js/bootstrap.min.js"></script> 
    <link href="static/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <script src="{% static 'js/custom.js' %}"></script>  
    <style>
		body {
		  background-image: url(static/img/home.jpg);
		}
	 </style>
</head>
<body>
<div class="row">
    <div class="col-md-6 mx-auto p-0">
        <div class="mainbox">
            <div class="login-box">
                <div class="login-snip"> 
					<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Log In</label> 
					<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
                    <div class="login-space">
                        <form action="dashboard.php" method="post">
							<div class="login">
								<div class="group"> <label for="user" class="label">Phone number</label> <input id="user" type="text" pattern="[0-9]{11}" title="invalid phone number" class="input" placeholder="03000000000" required> </div>
								<div class="group"> <label for="pass" class="label">Password</label> <input id="pass1" type="password" class="input" placeholder="Enter Password" required ><input class="showpassinput" id="showpasscheck" type="checkbox" onclick="showpassword1()"><label class="showpasslb">Show password</label></div>
								<div class="group"> <input id="check" type="checkbox" class="check" checked> <label for="check"><span class="icon"></span> Keep me Signed in</label> </div>
								<div class="group"> <input type="submit" class="button" value="Sign In"> </div>
								<div class="hr"></div>
								<div class="foot text-white"> <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModal">Forgot Password?</a> </div>
							</div>
						</form>
						
                       <form>
							<div class="sign-up-form">
								<fieldset>
								<div class="group"> <label for="user" class="label">User name</label> <input id="user" type="text" class="input" placeholder="Create your Username" required> </div>
								<div class="group"> <label for="user" class="label">Shop name</label> <input id="user" type="text" class="input" placeholder="Create your Shopname" required> </div>
								<div class="group"> <label for="pass" class="label">Phone Number</label> <input id="pass" type="text" pattern="[0-9]{11}" title="invalid phone number" class="input" placeholder="03000000000" required > </div>
								<div class="group"> <label for="pass" class="label">Email</label> <input id="pass" type="email" class="input validate" placeholder="abc@gmail.com" required> </div>
								<div class="group"> <label for="pass" id="pass1lb" class="label">Password</label> <input id="pass2" type="password" class="input" value=""  placeholder="Create your Password" required name=up1><input class="showpassinput" type="checkbox" onclick="showpassword2()" onkeyup='check();'><label class="showpasslb">Show password</label></div>
								<div class="group"> <label for="pass" id="pass2lb" class="label">Repeat Password</label> <input id="pass3" type="password" class="input" data-type="password" placeholder="Repeat your Password" oninput="check();" required > </div>
								<div class="group"> <input type="submit" id="signupbtn" class="button" value="Sign Up"> </div>
								<div id="snackbar">Repeat password not match</div>
								<div class="hr"></div>
								<!-- <div class="foot text-white"> <label for="tab-1"><a href="" >Already Member?</a></label> </div> -->
							    </fieldset>
							</div>
					   </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--forget password modal-->
<div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	  <div class="modal-content">
		<div class="modal-header">
		  <h5 class="modal-title text-white " id="exampleModalLabel">Forget Password</h5>
		  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">
			<form action="home.php" action="post">
			<div class="form-group">
				<label class="frgtmodal" for="usr">Email</label>
				<input type="email" class="form-control modalfm " id="usr" placeholder="abc@gmail.com" aria-describedby="emailHelp" required>
			  </div>
			  <br>
			  <div class="form-group">
				<label class="frgtmodal" for="pwd">New Password</label>
				<input type="password" class="form-control modalfm" id="pwd" required>
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Change Password</button>
			  </div>
		  </form>
		</div>
	  </div>
	</div>
  </div>

</body>
</html>