
var check = function() {

    if (document.getElementById('pass2').value ==
      document.getElementById('pass3').value) {
      document.getElementById('pass3').style.color = 'white';
      document.getElementById("signupbtn").disabled = false;

    } else {
      document.getElementById('pass3').style.color = 'red';
      document.getElementById("signupbtn").disabled = true;
      var x = document.getElementById("snackbar");
      x.className = "show";
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    }
  }


function showpassword1() {
    var x = document.getElementById("pass1");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  function showpassword2() {
    var x = document.getElementById("pass2");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }









$(document).ready(function() {
    var table = $('#example').DataTable({
        searchPanes: true
    });
    table.searchPanes.container().prependTo(table.table().container());
    table.searchPanes.resizePanes();
});





