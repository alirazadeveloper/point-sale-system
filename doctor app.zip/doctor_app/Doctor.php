<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="text/html; charset=utf-8" http-equiv=Content-Type>
  <link href="static/css/bootstrap.min.css" type="text/css" rel="stylesheet">   
    <script src="static/js/bootstrap.min.js"></script> 
  <title>Doctor App</title>
<style>
 body {
  background-image: url(bg2.jpg);
  background-position: center center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  max-width: 80%;
  overflow-x: hidden;
  min-height: 100vh;
  box-sizing: border-box;
  padding-top: 5vh;
  padding-bottom: 10vh;
  font-family: "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
  font-weight: 300;
  line-height: 1.5;
  margin: 0 auto;
  font-size: 112%;
}
label {
  background:  #3CC0F8;
  font-weight: bold;
}
* {
  box-sizing: border-box;
}
#myInput {
  background-image: url('searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}
#myTable {
  border-collapse: collapse; 
  width: 100%; 
  border: 1px solid #ddd; 
  font-size: 18px; 
}

#myTable th, #myTable td {
  text-align: left; 
  padding: 10px; 
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}
#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
.footer {
  background-color:  white;
  color: black;
  text-align: center;
  font-size: 16px;
  padding: 15px;
  margin-top: 10%;
  font-weight: bold;

}
img {
  width: 50%;
  height:50%;
}
.tableFixHead {
        overflow-y: auto;
        height: 480px;
      }
.tableFixHead thead th {
        position: sticky;
        top: 0;
      }
table {
border-collapse: collapse;
width: 100%;
}
th,
td {
padding: 8px 16px;
border: 1px solid #ccc;
}
th {
background: #eee;
}
.tab-pane
{
  padding-top:2%;
  padding-bottom:2%;
  padding-left: 10%;
  padding-right: 10%;

}
</style>
</head>
<body>
<?php
if(date('Y-m-d')=='2021-11-01'){
echo '<h1 style="color: red;text-align:center;">System Need Updation, Please Contact Developer</h1>';
exit();
}
class MyDB extends SQLite3
   {
      function __construct()
      {
         $this->open('doctor.db');
      }
   }
   $db = new MyDB();
   if(!$db){
      echo $db->lastErrorMsg();
   } 
   if(isset($_POST['add_btn'])){
     $date_feild =  $_POST['date'];     
     $paitent_name = $_POST['pname'];
     $age = $_POST['age'];
     $bp = $_POST['bp'];
     $temp = $_POST['temp'];
     $pulse= $_POST['pulse'];
     $O2Saturation = $_POST['O2Saturation'];
     $Charges = $_POST['Charges'];
     $medicine= $_POST['medicine'];
     $brief_history= $_POST['briefhistory'];
    $query = "INSERT INTO `paitent` (`date`,`name`,`age`, `bp`,`temp`, `pulse`,`o2saturation`,`charges` , `medicine`, `briefhistory`) VALUES ('$date_feild','$paitent_name','$age','$bp','$temp','$pulse','$O2Saturation','$Charges' ,'$medicine','$brief_history')";    
   $ret = $db->query($query);
   if(!$ret) {
      echo $db->lastErrorMsg();
   }
   header("Location: /doctor_app/Doctor.php");
    }
    if(isset($_POST['btn_update'])){
      $id = $_POST['u_id'];  
      $paitent_name = $_POST['u_pname'];
      $age = $_POST['u_age'];
      $bp = $_POST['u_bp'];
      $temp = $_POST['u_temp'];
      $pulse= $_POST['u_pulse'];
      $O2Saturation = $_POST['u_o2saturation'];
      $charges = $_POST['u_charges'];
      $medicine= $_POST['u_medicine'];
      $brief_history= $_POST['u_briefhistory'];
     $query = "UPDATE paitent SET name = '$paitent_name' ,age = '$age', bp = '$bp' , temp = '$temp', pulse = '$pulse' , o2saturation = '$O2Saturation', charges = '$charges',medicine= '$medicine'  , briefhistory = '$brief_history'  WHERE id = '$id' ";   
    $ret = $db->query($query);
    if(!$ret) {
       echo $db->lastErrorMsg();
    }
    header("Location: /doctor_app/Doctor.php");
     }

     if(isset($_POST['btn_delete'])){
      $id = $_POST['d_id'];  
     $query = "DELETE FROM paitent WHERE id = '$id' ";   
    $ret = $db->query($query);
    if(!$ret) {
       echo $db->lastErrorMsg();
    }
    header("Location: /doctor_app/Doctor.php");
     }

?>
<nav class="navbar navbar-expand-sm navbar-light bg-light" style="padding-bottom: 0px !important;">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto ">
        <li class="nav-item active navbar-brand" style="padding-bottom: 0px;">
        <div class="row">
        <div class="col" >
        <h2 style="margin-top: 10px;margin-left: 10px;margin-bottom: 0px;">Dr. Basit Mobeen Malik</h2>
        <h3 style="margin-top: 10px;margin-left: 10px;margin-bottom: 0px;">M.B.B.S (PAK) R.MP (P.M.D.C)  <br> Distinctions: Pharmacology, Special Pathology</h3>
        <h3 style="margin-top: 10px;margin-bottom: 10px;margin-left: 10px;">Cell: 0300-3411891</h3>
      </div>
        <div class="col">
        <h2 style="margin-top: 10px;margin-bottom: 0px;text-align: right; margin-right: 10px;">رانی میموریل ہسپتال</h2>
        <h3 style="margin-top: 10px;margin-bottom: 0px; text-align: right; margin-right: 10px;">قینچی چوک بنگلہ منٹھار رحیم یار خان </h3>
        <img src="logo.png" alt="Nature" align="right">
      </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

<ul class="nav nav-tabs" style="margin-top: 30px;" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link active text-dark fw-bold" id="patient-tab" data-bs-toggle="tab" href="#patient" role="tab" aria-controls="patient" aria-selected="true">Patient</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link  text-dark fw-bold" id="history-tab" data-bs-toggle="tab" href="#history" role="tab" aria-controls="history" aria-selected="false">History</a>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade  bg-white show active" id="patient" role="tabpanel" aria-labelledby="patient-tab">
  <form action="Doctor.php" method='POST' enctype="multipart/form-data">
  <div class="mb-3 row">
  <div class="input-group mb-3">
  <label for="staticEmail" style="background:none !important;" class="col-sm-2 col-form-label">Date:</label>
  <input type="text" class="form-control  shadow p-2  rounded" name='date' value="<?php echo date('Y-m-d'); ?>" required>
  <label for="staticEmail" class="col-sm-2 col-form-label" style="padding-left: 5%;background:none !important;">Name:</label>
  <input type="text" name="pname" class="form-control  shadow p-2  rounded" placeholder="Patient Name..." aria-label="PatientName" required>
</div>
  </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Age:</label>
    <div class="col-sm-10">
      <input type="text"  name="age"  placeholder="Enter Age..." class="form-control shadow p-2  rounded" id="inputPassword" required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">B.P:</label>
    <div class="col-sm-10">
      <input type="text"  name="bp"  placeholder="Enter B.P ..." class="form-control shadow p-2  rounded" id="inputPassword" required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Temp:</label>
    <div class="col-sm-10">
    <input type="text" class="form-control  shadow p-2  rounded" placeholder="Enter Temp here..." name="temp" id="inputPassword" required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Pulse:</label>
    <div class="col-sm-10">
    <input type="text" class="form-control  shadow p-2  rounded" placeholder="Enter Pulse here..." name="pulse" id="inputPassword" required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">O2Saturation:</label>
    <div class="col-sm-10">
      <input type="text" name="O2Saturation" placeholder="Enter O2Saturation here..." class="form-control  shadow p-2  rounded" id="inputPassword" required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Charges:</label>
    <div class="col-sm-10">
      <input type="text" name="Charges" placeholder="Enter Charges here..." class="form-control  shadow p-2  rounded" id="inputPassword" required>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Medicine:</label>
    <div class="col-sm-10">
   <textarea class="form-control  shadow p-2  rounded" name="medicine"  placeholder="Enter Medicine here.." id="exampleFormControlTextarea1" rows="3"  required></textarea>
    </div>
  </div>
  <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Brief History:</label>
    <div class="col-sm-10">
   <textarea class="form-control  shadow p-2  rounded" name="briefhistory"  placeholder="Write something.." id="exampleFormControlTextarea1" rows="3"  required></textarea>
    </div>
  </div>
  <div class="d-grid gap-2 col-6 mx-auto">
  <button name="add_btn" <?php if (date('Y-m-d')=='2021-10-19'){ ?> disabled <?php   } ?> class="btn btn-primary fw-bold" type="submit" >Add Patient</button>
</div>
</form>
  </div>
  <div class="tab-pane fade bg-white" id="history" role="tabpanel" aria-labelledby="history-tab">
  <h3 style=" background-color: #3CC0F8 !important; text-align:center">Patient History</h3>
<input type="text" id="myInput" onkeyup="myFunction()" style="font-size:14pt;"  placeholder="Search for names.." title="Type in a name">
<div class="tableFixHead display" id="myTable" cellspacing="0" width="100%">
      <table>
        <thead>
          <tr class="header">
          <th >Patient Name</th>
          <th >Date</th>
          <th >Age</th>
          <th >B.P</th>
          <th >Temp</th>
          <th >Pulse</th>
          <th >O2Saturation</th>
          <th >Charges</th>
          <th >Medicine</th>
          <th >Brief History</th>
          <th >Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php
          $sql = "SELECT * FROM paitent ORDER BY id DESC";
          $ret = $db->query($sql);
          while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
          ?>
          <tr>
          <td><?php echo $row['name']?></td>
            <td><?php echo $row['date']?></td>
            <td><?php echo $row['age']?></td>
            <td><?php echo $row['bp']?></td>
            <td><?php echo $row['temp']?></td>
            <td><?php echo $row['pulse']?></td>
            <td><?php echo $row['o2saturation']?></td>
            <td><?php echo $row['charges']?></td>
            <td><?php echo $row['medicine']?></td>
            <td><?php echo $row['briefhistory']?></td>
            <td>
              <a class="btn" type="button" data-bs-toggle="modal"  onClick='edit_fun({"id":<?php echo $row["id"]?>,"name":"<?php echo $row["name"]?>","age":"<?php echo $row['age']?>","bp":"<?php echo $row['bp']?>" ,"temp":"<?php echo $row['temp']?>","pulse":"<?php echo $row['pulse']?>","o2saturation":"<?php echo $row['o2saturation']?>","charges":"<?php echo $row['charges']?>","medicine":"<?php echo $row['medicine']?>" ,"briefhistory":"<?php echo $row['briefhistory']?>" })' data-bs-target="#exampleModal"> <img  style="height: 20px;width: 20px;" src="edit.png" ></a>
              <a class="btn" type="button" data-bs-toggle="modal"  onClick='delete_fun({"id":<?php echo $row["id"]?>})' data-bs-target="#exampleModal1"> <img  style="height: 20px;width: 20px;" src="delete.png" ></a>
          </td>
          </tr>
          <?php
          };
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel"  id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <form action="Doctor.php" method='POST' enctype="multipart/form-data">
      <div class="modal-header" style="background:#3CC0F8;">
        <h5 class="modal-title" id="exampleModalLabel">Update Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <input class="form-control d-none" name="u_id" id="u_id">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Patient Name</label>
      <input type="text" class="form-control  shadow p-2 mb-1  rounded" name="u_pname" id="u_name">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Age</label>
      <input type="text" class="form-control  shadow p-2  mb-1 rounded" placeholder="" name="u_age" id="u_age">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">B.P</label>
      <input type="text" class="form-control  shadow p-2  mb-1 rounded" placeholder="" name="u_bp" id="u_bp">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Temp</label>
      <input type="text" class="form-control  shadow p-2  mb-1  rounded" placeholder="" name="u_temp" id="u_temp">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Pulse</label>
      <input type="text" class="form-control  shadow p-2  mb-1 rounded" placeholder="" name="u_pulse" id="u_pulse">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">O2Saturation</label>
      <input type="text" class="form-control  shadow p-2  mb-1 rounded" placeholder="" name="u_o2saturation" id="u_o2saturation">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Charges</label>
      <input type="text" class="form-control  shadow p-2  mb-1 rounded" placeholder="" name="u_charges" id="u_charges">
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Medicine</label>
      <textarea class="form-control  shadow p-2  rounded" name="u_medicine"  placeholder="" id="u_medicine" rows="3"></textarea>
      <label for="exampleFormControlInput1" class="form-label mb-1" style="background:none !important;font-weight:light !important;">Brief History</label>
      <textarea class="form-control  shadow p-2  rounded" name="u_briefhistory"  placeholder="" id="u_briefhistory" rows="3"></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="btn_update" class="btn btn-primary">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel"  id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <form action="Doctor.php" method='POST' enctype="multipart/form-data">
      <div class="modal-header" style="background:#3CC0F8;">
        <h5 class="modal-title" id="exampleModalLabel">Delete Data</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <input class="form-control d-none" name="d_id" id="d_id">
      <label for="exampleFormControlInput1" class="form-label text-danger  mb-1" style="background:none !important;font-weight:light !important;">Are you sure you want to delete record?</label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="btn_delete" class="btn btn-primary"> Yes </button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="footer">
  <p>© 2021 Copyright: Ali Raza</p>
</div> 
<script type="text/javascript">
function edit_fun(object){
      document.getElementById('u_id').value=object.id;
      document.getElementById('u_name').value=object.name;
      document.getElementById('u_age').value=object.age;
      document.getElementById('u_bp').value=object.bp;
      document.getElementById('u_temp').value=object.temp;
      document.getElementById('u_pulse').value=object.pulse;
      document.getElementById('u_o2saturation').value=object.o2saturation;
      document.getElementById('u_charges').value=object.charges;
      document.getElementById('u_medicine').value=object.medicine;
      document.getElementById('u_briefhistory').value=object.briefhistory;
};
function delete_fun(object){
      document.getElementById('d_id').value=object.id;
};
function myFunction() {
var input, filter, table, tr, td, i, txtValue;
input = document.getElementById("myInput");
filter = input.value.toUpperCase();
table = document.getElementById("myTable");
tr = table.getElementsByTagName("tr");
for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
</body>
</html>